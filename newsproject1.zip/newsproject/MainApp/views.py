from django.shortcuts import render
import requests

# Create your views here.
from datetime import date
from datetime import timedelta
 
# Get today's date
today = date.today()
print("Today is: ", today)
 
# Yesterday date
yesterday = today - timedelta(days = 1)
print("Yesterday was: ", yesterday)
def index(request):

    url = 'https://newsapi.org/v2/everything?q=rahulgandhi&from='+str(yesterday)+'&sortBy=popularity&apiKey=1373e3c29d8d4ea4b8fb53a549c7f209'
    if request.method == 'POST':
        news = request.POST.get('news')
        url = 'https://newsapi.org/v2/everything?q='+news+'&from='+str(yesterday)+'&sortBy=popularity&apiKey=1373e3c29d8d4ea4b8fb53a549c7f209'


    crypto_news = requests.get(url).json()
    print(crypto_news)
    a = crypto_news['articles']
    desc =[]
    title =[]
    img =[]

    for i in range(len(a)):
        f = a[i]
        title.append(f['title'])
        desc.append(f['description'])
        img.append(f['urlToImage'])
    mylist = zip(title, desc, img)

    context = {'mylist': mylist}

    return render(request, 'index.html', context)